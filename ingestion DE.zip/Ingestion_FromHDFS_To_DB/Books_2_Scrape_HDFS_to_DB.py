from hdfs import InsecureClient
import pandas as pd
from sqlalchemy import create_engine
import io

# ---------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------

hdfs_url = 'http://192.168.56.102:9870'
client = InsecureClient(hdfs_url, user='hadoop', timeout=60)

BOOK_PATH = '/Scraping_Data/all_books_with_details_2.csv'

engine = create_engine(
    'mysql+pymysql://root:123123@localhost:3306/DE_Project'
)

# ---------------------------------------------------------------
# Helper Function to read CSV from HDFS
# ---------------------------------------------------------------

def read_csv_from_hdfs(hdfs_path):
    print(f"🔹 Reading from HDFS path: {hdfs_path}")
    with client.read(hdfs_path) as byte_stream:
        file_content = byte_stream.read()
    text_buffer = io.StringIO(file_content.decode('utf-8'))
    df = pd.read_csv(text_buffer)
    print(f"✅ Read CSV from HDFS. Columns: {df.columns.tolist()}")
    return df

# ---------------------------------------------------------------
# Main Data Processing
# ---------------------------------------------------------------

df = read_csv_from_hdfs(BOOK_PATH)

# Clean and transform

df = df.drop_duplicates()

df['Price'] = df['Price'].str.replace('£', '').astype(float)

rating_map = {'One':1, 'Two':2, 'Three':3, 'Four':4, 'Five':5}
df['Star Rating'] = df['Star Rating'].map(rating_map)

df['Category'] = df['Category'].str.strip()
df['Availability'] = df['Availability'].str.strip()

# Create categories table with unique IDs
categories_df = df[['Category']].drop_duplicates().reset_index(drop=True)
categories_df['category_id'] = categories_df.index + 1  # simple ID starting from 1

# Map category names in books to category_id
df = df.merge(categories_df, on='Category', how='left')

# Prepare books table columns (exclude Category name, include category_id)
books_df = df[['Title', 'Price', 'Star Rating', 'Availability', 'Link', 'category_id']]

# Write to DB
categories_df.to_sql('categories', con=engine, if_exists='replace', index=False)
books_df.to_sql('books', con=engine, if_exists='replace', index=False)

print("✅ Data loaded successfully into 'books' and 'categories' tables.")
