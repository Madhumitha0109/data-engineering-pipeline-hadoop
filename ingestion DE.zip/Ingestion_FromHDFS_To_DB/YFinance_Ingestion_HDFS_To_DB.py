from hdfs import InsecureClient
import pandas as pd
from sqlalchemy import create_engine
import io

# ---------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------

hdfs_url = 'http://192.168.56.102:9870'
client = InsecureClient(hdfs_url, user='hadoop', timeout=60)

FILE_PATH = '/Scraping_Data/us_stock_data_yfinance.csv'

engine = create_engine(
    'mysql+pymysql://root:123123@localhost:3306/DE_Project'
)

# ---------------------------------------------------------------
# Helper function to read CSV from HDFS
# ---------------------------------------------------------------

def read_csv_from_hdfs(hdfs_path):
    with client.read(hdfs_path) as byte_stream:
        file_content = byte_stream.read()
    text_buffer = io.StringIO(file_content.decode('utf-8'))
    df = pd.read_csv(text_buffer)
    return df

# ---------------------------------------------------------------
# Main Processing
# ---------------------------------------------------------------

df = read_csv_from_hdfs(FILE_PATH)

print("Columns in CSV:", df.columns.tolist())

# Detect symbol column (e.g., 'symbol', 'ticker')
symbol_col = None
for col in df.columns:
    if 'symbol' in col.lower() or 'ticker' in col.lower():
        symbol_col = col
        break
if symbol_col is None:
    raise ValueError("No stock symbol column found!")

# Rename to 'Symbol'
df = df.rename(columns={symbol_col: 'Symbol'})

# Detect date column (e.g., 'date', 'timestamp')
date_col = None
for col in df.columns:
    if 'date' in col.lower() or 'time' in col.lower():
        date_col = col
        break

if date_col:
    df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
    print(f"Using '{date_col}' as date column.")
else:
    print("No date column found.")

df = df.drop_duplicates()

# Create stocks table
stocks_df = df[['Symbol']].drop_duplicates().reset_index(drop=True)
stocks_df['stock_id'] = stocks_df.index + 1

# Create dates table if date column found
if date_col:
    dates_df = df[[date_col]].drop_duplicates().reset_index(drop=True)
    dates_df['date_id'] = dates_df.index + 1
    # Merge foreign keys into original df
    df = df.merge(stocks_df, on='Symbol', how='left')
    df = df.merge(dates_df, on=date_col, how='left')
else:
    df = df.merge(stocks_df, on='Symbol', how='left')
    df['date_id'] = None
    dates_df = None

# Prepare stock_prices table
cols = ['stock_id', 'date_id']
# Add all numeric columns except symbol and date
numeric_cols = [c for c in df.columns if c not in ['Symbol', date_col, 'stock_id', 'date_id']]
cols += numeric_cols
stock_prices_df = df[cols]

# Write to MySQL
stocks_df.to_sql('stocks', con=engine, if_exists='replace', index=False)
if dates_df is not None:
    dates_df.to_sql('dates', con=engine, if_exists='replace', index=False)
stock_prices_df.to_sql('stock_prices', con=engine, if_exists='replace', index=False)

print("✅ Data loaded into 'stocks', 'dates' (if exists), and 'stock_prices' tables successfully.")
